package com.icici.apigw.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public class Utility {

    public static boolean isValidEmailAddress(String email) {
        String ePattern = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$";
        java.util.regex.Pattern p = java.util.regex.Pattern.compile(ePattern);
        java.util.regex.Matcher m = p.matcher(email);
        return m.matches();
    }
    
    public static String encodeBase64(String s) {
        return Base64.getEncoder().encodeToString(s.getBytes());
    }

    public static String decodeBase64(String s) {
        return new String(Base64.getDecoder().decode(s.getBytes()));
    }
    
    public static String sha1(String input) {
        MessageDigest mDigest;
        StringBuffer sb = new StringBuffer();
		try {
			mDigest = MessageDigest.getInstance("SHA1");
			byte[] result = mDigest.digest(input.getBytes());
	        for (int i = 0; i < result.length; i++) {
	            sb.append(Integer.toString((result[i] & 0xff) + 0x100, 16).substring(1));
	        }
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		return sb.toString();
    }
    
    private static final String HMAC_SHA512_ALGORITHM = "HmacSHA512";
    
    public static String hmacSha512(String data, String key) {
    	String result = null;
        try {
            SecretKeySpec signingKey = new SecretKeySpec(key.getBytes(),HMAC_SHA512_ALGORITHM);
            Mac mac = Mac.getInstance(HMAC_SHA512_ALGORITHM);
            mac.init(signingKey);
            byte[] rawHmac = mac.doFinal(data.getBytes());
            result = Base64.getEncoder().encodeToString(rawHmac);
        } catch (Exception e) {
           e.printStackTrace();
        }
        return result;
    }
    
    public static String convertStreamToString(InputStream is) {
        ByteArrayOutputStream oas = new ByteArrayOutputStream();
        copyStream(is, oas);
        String t = oas.toString();
        try {
            oas.close();
            oas = null;
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return t;
    }

    private static void copyStream(InputStream is, OutputStream os) {
        final int buffer_size = 1024;
        try {
            byte[] bytes = new byte[buffer_size];
            for (; ; ) {
                int count = is.read(bytes, 0, buffer_size);
                if (count == -1)
                    break;
                os.write(bytes, 0, count);
            }
        } catch (Exception ex) {
        }
    }
    
    public static void main(String[] args) {
		System.out.println(sha1("admin"));
		System.out.println(sha1("7layer"));
		System.out.println(sha1("ssboraji"));
		System.out.println(hmacSha512("Secureapi@7", "c0005dc4-d2ba-4e38-8bc5-e8377441fb23"));
		System.out.println(hmacSha512("Secureapi@7", "c0005dc4-d2ba-4e38-8bc5-e8377441fb23"));
		System.out.println(hmacSha512("Secureapi@7", "c0005dc4-d2ba-4e38-8bc5-e8377441fb23"));
	}
    
    public static String LoadApiData = "{" +
            "    \"ApiData\": {" +
            "        \"ApiId\": \"143\"," +
            "        \"ApiDomain\": \"Payments\"," +
            "        \"ApiName\": \"Merchant Refund Request \"," +
            "        \"ApiDesc\": \"Refund API works depending on the Channel of the Original Transaction. UPI will only initiate Credit for specific Channels. Otherwise it will act like 'Get Payer Details' for other channel. API works based on the 'seq-no' of the original transaction.\"," +
            "        \"ApiSubDomain\": \"Upi 1.0\"," +
            "        \"SandboxUrl\": \"PaymentsUPI1MerchantRefundRequest\"" +
            "    }," +
            "    \"ReqParam\": [" +
            "        {" +
            "            \"ReqId\": \"1376\"," +
            "            \"ReqName\": \"Device-id\"," +
            "            \"ReqType\": \"String\"," +
            "            \"ReqDesc\": \"Unique device Token. Token should be unique for per channel-user.\"," +
            "            \"ReqMand\": \"Y\"" +
            "        }," +
            "        {" +
            "            \"ReqId\": \"1377\"," +
            "            \"ReqName\": \"Mobile\"," +
            "            \"ReqType\": \"Int\"," +
            "            \"ReqDesc\": \"Mobile Number of the user.\"," +
            "            \"ReqMand\": \"Y\"" +
            "        }," +
            "        {" +
            "            \"ReqId\": \"1378\"," +
            "            \"ReqName\": \"Seq-no\"," +
            "            \"ReqType\": \"String\"," +
            "            \"ReqDesc\": \"This will be a txn-id generated by the Mobile APP. This id will be used in the NPCI Common Library at the time of encrypting the OTP/MPIN.\"," +
            "            \"ReqMand\": \"Y\"" +
            "        }," +
            "        {" +
            "            \"ReqId\": \"1379\"," +
            "            \"ReqName\": \"Channel-code\"," +
            "            \"ReqType\": \"String\"," +
            "            \"ReqDesc\": \"The code for the source application from which the transaction will be initiated.\"," +
            "            \"ReqMand\": \"Y\"" +
            "        }," +
            "        {" +
            "            \"ReqId\": \"1380\"," +
            "            \"ReqName\": \"Profile-id\"," +
            "            \"ReqType\": \"Int\"," +
            "            \"ReqDesc\": \"ID of the profile returned in the response of the ‘register mobile/store-acc-details’API. This will uniquely identify the user’s profile.\"," +
            "            \"ReqMand\": \"Y\"" +
            "        }," +
            "        {" +
            "            \"ReqId\": \"1381\"," +
            "            \"ReqName\": \"Payer-va\"," +
            "            \"ReqType\": \"Int\"," +
            "            \"ReqDesc\": \"Alias name with which the payer can be identified by his registered entity.\"," +
            "            \"ReqMand\": \"Y\"" +
            "        }," +
            "        {" +
            "            \"ReqId\": \"1382\"," +
            "            \"ReqName\": \"Ori-seq-no\"," +
            "            \"ReqType\": \"String\"," +
            "            \"ReqDesc\": \"Seq No of the original transaction for which we are checking the status.\"," +
            "            \"ReqMand\": \"Y\"" +
            "        }" +
            "    ]," +
            "    \"ResParam\": [" +
            "        {" +
            "            \"ResId\": \"1248\"," +
            "            \"ResName\": \"Success\"," +
            "            \"ResDesc\": \"Denotes if service all has successfully completed.\"," +
            "            \"ResType\": \"String\"" +
            "        }," +
            "        {" +
            "            \"ResId\": \"1249\"," +
            "            \"ResName\": \"Response\"," +
            "            \"ResDesc\": \"Response code of the API. Response code \\\"0\\\" indicates the success response.\"," +
            "            \"ResType\": \"Int\"" +
            "        }," +
            "        {" +
            "            \"ResId\": \"1250\"," +
            "            \"ResName\": \"Message\"," +
            "            \"ResDesc\": \"Response code description message.\"," +
            "            \"ResType\": \"String\"" +
            "        }," +
            "        {" +
            "            \"ResId\": \"1251\"," +
            "            \"ResName\": \"BankRRN\"," +
            "            \"ResDesc\": \"The reference number of the transaction.\"," +
            "            \"ResType\": \"Int\"" +
            "        }," +
            "        {" +
            "            \"ResId\": \"1252\"," +
            "            \"ResName\": \"UpiTranlogId\"," +
            "            \"ResDesc\": \"The Transaction ID generated by Switch.\"," +
            "            \"ResType\": \"Int\"" +
            "        }," +
            "        {" +
            "            \"ResId\": \"1253\"," +
            "            \"ResName\": \"UserProfile\"," +
            "            \"ResDesc\": \"Profile Id of the user.\"," +
            "            \"ResType\": \"Int\"" +
            "        }," +
            "        {" +
            "            \"ResId\": \"1254\"," +
            "            \"ResName\": \"MobileAppData\"," +
            "            \"ResDesc\": \"Denotes the extra data or information to be shared with mobile APP.\"," +
            "            \"ResType\": \"String\"" +
            "        }," +
            "        {" +
            "            \"ResId\": \"1255\"," +
            "            \"ResName\": \"SeqNo\"," +
            "            \"ResDesc\": \"Seq-no input parameter will be echoed back.\"," +
            "            \"ResType\": \"String\"" +
            "        }" +
            "    ]" +
            "}";

    public static String LoadErrorCodes = "[" +
            "    {" +
            "        \"ErrId\": \"1\"," +
            "        \"ErrCode\": \"8001\"," +
            "        \"ErrMsg\": \"JSON is EMPTY\"," +
            "        \"ErrDesc\": \"JSON schema request empty.\"" +
            "    }," +
            "    {" +
            "        \"ErrId\": \"2\"," +
            "        \"ErrCode\": \"8002\"," +
            "        \"ErrMsg\": \"INVALID_JSON\"," +
            "        \"ErrDesc\": \"JSON is not valid.\"" +
            "    }," +
            "    {" +
            "        \"ErrId\": \"3\"," +
            "        \"ErrCode\": \"8003\"," +
            "        \"ErrMsg\": \"INVALID_FIELD FORMAT OR LENGTH\"," +
            "        \"ErrDesc\": \"Field is not in the format mentioned.\"" +
            "    }," +
            "    {" +
            "        \"ErrId\": \"4\"," +
            "        \"ErrCode\": \"8004\"," +
            "        \"ErrMsg\": \"MISSING_REQUIRED_FIELD\"," +
            "        \"ErrDesc\": \"Mandatory field is missing.\"" +
            "    }," +
            "    {" +
            "        \"ErrId\": \"5\"," +
            "        \"ErrCode\": \"8006\"," +
            "        \"ErrMsg\": \"INVALID_FIELD_LENGTH\"," +
            "        \"ErrDesc\": \"Length of field exceeds defined length.\"" +
            "    }," +
            "    {" +
            "        \"ErrId\": \"6\"," +
            "        \"ErrCode\": \"8007\"," +
            "        \"ErrMsg\": \"Invalid JSON,OPEN CURLY BRACE MISSING.\"," +
            "        \"ErrDesc\": \"Open Brace missing in JSON.\"" +
            "    }," +
            "    {" +
            "        \"ErrId\": \"7\"," +
            "        \"ErrCode\": \"8008\"," +
            "        \"ErrMsg\": \"Invalid JSON,END CURLY BRACE MISSING.\"," +
            "        \"ErrDesc\": \"Closing Brace missing in JSON.\"" +
            "    }," +
            "    {" +
            "        \"ErrId\": \"8\"," +
            "        \"ErrCode\": \"8009\"," +
            "        \"ErrMsg\": \"Internal Server Error\"," +
            "        \"ErrDesc\": \"White space characters.\"" +
            "    }," +
            "    {" +
            "        \"ErrId\": \"9\"," +
            "        \"ErrCode\": \"8010\"," +
            "        \"ErrMsg\": \"Internal Service Failure\"," +
            "        \"ErrDesc\": \"Routing Failure.\"" +
            "    }," +
            "    {" +
            "        \"ErrId\": \"10\"," +
            "        \"ErrCode\": \"8011\"," +
            "        \"ErrMsg\": \"INVALID_FIELD\"," +
            "        \"ErrDesc\": \"INVALID_FIELD\"" +
            "    }" +
            "]";

    public static String LoadApiPacket = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
            "<ns0:CMSCHWService" +
            "\txmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"" +
            "\txmlns:ns0=\"http://xml.netbeans.org/schema/CMSCHWService\" xsi:schemaLocation=\"http://xml.netbeans.org/schema/CMSCHWService CHWReqType.xsd http://xml.netbeans.org/schema/CMSCHWService CHWHeaderType.xsd http://xml.netbeans.org/schema/CMSCHWService CHWResType.xsd http://xml.netbeans.org/schema/CMSCHWService CMSCHWService.xsd\">" +
            "    <ns0:Header>" +
            "        <ns0:Version>1.0</ns0:Version>" +
            "        <ns0:SrcApp>VCHW</ns0:SrcApp>" +
            "        <ns0:TargetApp>DH</ns0:TargetApp>" +
            "        <ns0:SrcMsgId>00000001198469411500</ns0:SrcMsgId>" +
            "        <ns0:TranTimeStamp>20180125031729</ns0:TranTimeStamp>" +
            "    </ns0:Header>" +
            "    <ns0:Body>" +
            "        <ns0:CHWReq>" +
            "            <ns0:DeliveryChnl>17</ns0:DeliveryChnl>" +
            "            <ns0:TranCde>12</ns0:TranCde>" +
            "            <ns0:RvslCde>00</ns0:RvslCde>" +
            "            <ns0:RRN>20181123457889</ns0:RRN>" +
            "            <ns0:CardNumber>4336620020553121</ns0:CardNumber>" +
            "            <ns0:Username></ns0:Username>" +
            "            <ns0:LocalTranDate>20181125</ns0:LocalTranDate>" +
            "            <ns0:LocalTranTime>031729</ns0:LocalTranTime>" +
            "            <ns0:FirstName></ns0:FirstName>" +
            "            <ns0:LastName></ns0:LastName>" +
            "            <ns0:DOB></ns0:DOB>" +
            "            <ns0:PhoneNumber>7977364606</ns0:PhoneNumber>" +
            "            <ns0:MobileNumber>7977364606</ns0:MobileNumber>" +
            "            <ns0:Email></ns0:Email>" +
            "            <ns0:AddLineOne></ns0:AddLineOne>" +
            "            <ns0:AddLineTwo></ns0:AddLineTwo>" +
            "            <ns0:City>RATNAGIRI</ns0:City>" +
            "            <ns0:State>23</ns0:State>" +
            "            <ns0:ZIP>415622</ns0:ZIP>" +
            "            <ns0:CountryCode>1</ns0:CountryCode>" +
            "            <ns0:IPAddress>172.16.13.70</ns0:IPAddress>" +
            "            <ns0:Gender></ns0:Gender>" +
            "            <ns0:Remark>FLIPKART Card Update </ns0:Remark>" +
            "            <ns0:Nationality>In</ns0:Nationality>" +
            "            <ns0:MotherMaidenName></ns0:MotherMaidenName>" +
            "            <ns0:CorporateID></ns0:CorporateID>" +
            "            <ns0:LegalIDType1>Passport</ns0:LegalIDType1>" +
            "            <ns0:LegalIDNo1>H1234567</ns0:LegalIDNo1>" +
            "            <ns0:LegalIDType2></ns0:LegalIDType2>" +
            "            <ns0:LegalIDNo2></ns0:LegalIDNo2>" +
            "            <ns0:employeeID></ns0:employeeID>" +
            "            <ns0:CommunicationADDRESS1></ns0:CommunicationADDRESS1>" +
            "            <ns0:CommunicationADDRESS2></ns0:CommunicationADDRESS2>" +
            "            <ns0:CommunicationCITY></ns0:CommunicationCITY>" +
            "            <ns0:CommunicationState></ns0:CommunicationState>" +
            "            <ns0:CommunicationCountryCode>1</ns0:CommunicationCountryCode>" +
            "            <ns0:CommunicationZIP></ns0:CommunicationZIP>" +
            "            <ns0:GSTno></ns0:GSTno>" +
            "            <ns0:LimitPlanID></ns0:LimitPlanID>" +
            "            <ns0:FeePlanID></ns0:FeePlanID>" +
            "            <ns0:RuleGrpCode></ns0:RuleGrpCode>" +
            "            <ns0:MerchantId>FLP0000001</ns0:MerchantId>" +
            "            <ns0:MerchantPassword>admin12345</ns0:MerchantPassword>" +
            "            <ns0:CustomerPANNO></ns0:CustomerPANNO>" +
            "            <ns0:CustomerType>ICICIRetail</ns0:CustomerType>" +
            "            <ns0:KYCDate>23112018</ns0:KYCDate>" +
            "            <ns0:BankAccountNumber></ns0:BankAccountNumber>" +
            "            <ns0:NameInBankAccount></ns0:NameInBankAccount>" +
            "            <ns0:IFSCcode></ns0:IFSCcode>" +
            "            <ns0:AadhaarNo>438412347896</ns0:AadhaarNo>" +
            "            <ns0:AadhaarName>SRINIVAS</ns0:AadhaarName>" +
            "            <ns0:AadhaarGender></ns0:AadhaarGender>" +
            "            <ns0:AadhaarDOB>01011988</ns0:AadhaarDOB>" +
            "            <ns0:KYCStatus>M</ns0:KYCStatus>" +
            "            <ns0:AadhaarPhonenumber>7977364606</ns0:AadhaarPhonenumber>" +
            "            <ns0:AdharAddress></ns0:AdharAddress>" +
            "            <ns0:ICICIRelationshipNumber></ns0:ICICIRelationshipNumber>" +
            "        </ns0:CHWReq>" +
            "    </ns0:Body>" +
            "</ns0:CMSCHWService>";
}