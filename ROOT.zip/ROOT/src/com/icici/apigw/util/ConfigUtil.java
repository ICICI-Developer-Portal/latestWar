package com.icici.apigw.util;

import java.util.ResourceBundle;

public class ConfigUtil {
	private static final ResourceBundle RB = ResourceBundle.getBundle("config");
	
	public static String get(String key) {
		return RB.getString(key);
	}
}
