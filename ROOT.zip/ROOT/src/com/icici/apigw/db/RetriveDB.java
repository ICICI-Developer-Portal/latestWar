package com.icici.apigw.db;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;
import java.util.logging.Logger;

import org.json.JSONException;

import com.icici.apigw.util.GwConstants;

public class RetriveDB {
private static final Logger logger=Logger.getLogger(RetriveDB.class.getName());
	Connection con=null;
	PreparedStatement prestmt=null;
	ResultSet rs=null;
	
	public Connection getdbConnect() throws SQLException, IOException {
		logger.info("connection open");
		InputStream read=getClass().getClassLoader().getResourceAsStream("config.properties");
		Properties prop=new Properties();
		prop.load(read);
		try {
			Class.forName(GwConstants.DB_DOC_DRIVER);
			con = DriverManager.getConnection(GwConstants.DB_DOC_URL, GwConstants.DB_DOC_USERNAME, GwConstants.DB_DOC_PASSWORD);
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} 
		return con;	
	}
	public Map temporary(String Key, String Value , String TREE_ID, String status,String position) 
	{
	    Map <String, String>temp =new  LinkedHashMap<String, String>(); 
	    temp.put(Key, Value);
	    temp.put("TREE_ID", TREE_ID);
	    temp.put("STATUS", status);
	    temp.put("POSITION", position);

	    return temp;
	}
	public Map temporary(  String TREE_ID) 
	{
	    Map <String, String>temp =new  LinkedHashMap<String, String>(); 
	    
	    temp.put("TREE_ID", TREE_ID);
	    return temp;
	}
	
   public Map dbOpr(Connection conn,String id) throws IOException, SQLException, JSONException {
	    Map <String, Map<String, String>>Data =new  LinkedHashMap<String, Map<String, String>>();
	    Map <String, String>temp =new  LinkedHashMap<String, String>(); 

	    temp.put("API_ID","1");


     	try {
		prestmt=conn.prepareStatement("Select * from PORTAL_MENU_TREE Where PARENT_ID = ? order by POSITION asc");
		prestmt.setString(1, id);
		rs=prestmt.executeQuery();
		while(rs.next()) {
			int child_count = rs.getInt("CHILD_COUNT");
			if(child_count==0)
			{	temp= temporary(rs.getString("PARENT_ID"));
				Data.put("ID",temp);
				temp= temporary("API_ID",rs.getString("API_ID"),rs.getString("ID"),rs.getString("STATUS"),rs.getString("POSITION"));
				Data.put(rs.getString("TAB_NAME"),temp);
				
				
			}
			else
			{
			/*logger.info("TAB_Name:: "+rs.getString("TAB_NAME"));*/
			String parent_id=rs.getString("ID");
			if(rs.getInt("PARENT_ID")!=0)
			{
			temp= temporary(rs.getString("PARENT_ID"));
			Data.put("ID",temp);
			}
			Data.put(rs.getString("TAB_NAME"),new RetriveDB().dbOpr(conn,parent_id));
			
			}
			
		}
		return Data;
	    } catch (SQLException e) {
	    	
		temp.put("Error", e.toString());
		Data.put("Error",temp);

		return Data;
	    }
	    finally {
	    prestmt.close();
		/*System.out.println();
		logger.info("Connection Closed");*/
	    }	
   }
	
   /*public static void main(String[] args) throws IOException, SQLException, JSONException {
	   	Connection conn=new RetriveDB().getdbConnect();
		System.out.println("Output:: "+new RetriveDB().dbOpr(conn,"0"));
		String json=new JSONObject(new RetriveDB().dbOpr(conn,"0")).toString();
		System.out.println("Output:: "+json);
		conn.close();
	}*/

}
