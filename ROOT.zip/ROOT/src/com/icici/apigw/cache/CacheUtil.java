package com.icici.apigw.cache;

import com.icici.apigw.util.GwConstants;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;

public class CacheUtil {

	private static CacheManager cacheManager;

	public static Cache getApiDtlsCache() {
		if (cacheManager == null) {
			cacheManager = CacheManager.getInstance();
		}
		return cacheManager.getCache(GwConstants.CACHE_STORE_API_DTL);
	}
	
	public static Cache getApiPktCache() {
		if (cacheManager == null) {
			cacheManager = CacheManager.getInstance();
		}
		return cacheManager.getCache(GwConstants.CACHE_STORE_API_PKT);
	}
	
	public static Cache getMenuTreeDetailsCache() {
		if (cacheManager == null) {
			cacheManager = CacheManager.getInstance();
		}
		return cacheManager.getCache(GwConstants.CACHE_STORE_MENU_DTLS);
	}

	/*
	 * Shutdown- To close the cache manager
	 */
	public static void close(CacheManager cm) {
		cm.shutdown();
	}

}
