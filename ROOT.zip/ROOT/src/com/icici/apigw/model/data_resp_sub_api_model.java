package com.icici.apigw.model;

public class data_resp_sub_api_model {
    public String ApiId;
    public String name;
}
