package com.icici.apigw.model;

import java.sql.Date;

public class MerchantOnboardingDt {

	String userName;
	String env;
	String merchantName;
	String description;
	String spocEmail;
	String spocPhone;
	String relManager;
	Date requestDt;
	String domain;
	String domainApi;
	String ipList;
	String callbackUrl;
	String jiraId;
	String refJiraId;
	String jiraStatus;
	String whizibleCr;
	String ndaSigned;
	Date ndaSignedDt;
	String url;
	String certificate;
	

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getCertificate() {
		return certificate;
	}

	public void setCertificate(String certificate) {
		this.certificate = certificate;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEnv() {
		return env;
	}

	public void setEnv(String env) {
		this.env = env;
	}

	public String getMerchantName() {
		return merchantName;
	}

	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getSpocEmail() {
		return spocEmail;
	}

	public void setSpocEmail(String spocEmail) {
		this.spocEmail = spocEmail;
	}

	public String getSpocPhone() {
		return spocPhone;
	}

	public void setSpocPhone(String spocPhone) {
		this.spocPhone = spocPhone;
	}

	public String getRelManager() {
		return relManager;
	}

	public void setRelManager(String relManager) {
		this.relManager = relManager;
	}

	public Date getRequestDt() {
		return requestDt;
	}

	public void setRequestDt(Date requestDt) {
		this.requestDt = requestDt;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getDomainApi() {
		return domainApi;
	}

	public void setDomainApi(String domainApi) {
		this.domainApi = domainApi;
	}

	public String getIpList() {
		return ipList;
	}

	public void setIpList(String ipList) {
		this.ipList = ipList;
	}

	public String getCallbackUrl() {
		return callbackUrl;
	}

	public void setCallbackUrl(String callbackUrl) {
		this.callbackUrl = callbackUrl;
	}

	public String getJiraId() {
		return jiraId;
	}

	public void setJiraId(String jiraId) {
		this.jiraId = jiraId;
	}

	public String getRefJiraId() {
		return refJiraId;
	}

	public void setRefJiraId(String refJiraId) {
		this.refJiraId = refJiraId;
	}

	public String getJiraStatus() {
		return jiraStatus;
	}

	public void setJiraStatus(String jiraStatus) {
		this.jiraStatus = jiraStatus;
	}

	public String getWhizibleCr() {
		return whizibleCr;
	}

	public void setWhizibleCr(String whizibleCr) {
		this.whizibleCr = whizibleCr;
	}

	public String getNdaSigned() {
		return ndaSigned;
	}

	public void setNdaSigned(String ndaSigned) {
		this.ndaSigned = ndaSigned;
	}

	public Date getNdaSignedDt() {
		return ndaSignedDt;
	}

	public void setNdaSignedDt(Date ndaSignedDt) {
		this.ndaSignedDt = ndaSignedDt;
	}

}
