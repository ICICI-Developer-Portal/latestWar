package com.icici.apigw.model;


public class ApiData {
	
	private String apiId, apiDomain, apiName, apiDesc, apiSubDomain, sandboxUrl;

	public String getApiId() {
		return apiId;
	}

	public void setApiId(String apiId) {
		this.apiId = apiId;
	}

	public String getApiDomain() {
		return apiDomain;
	}

	public void setApiDomain(String apiDomain) {
		this.apiDomain = apiDomain;
	}

	public String getApiName() {
		return apiName;
	}

	public void setApiName(String apiName) {
		this.apiName = apiName;
	}

	public String getApiDesc() {
		return apiDesc;
	}

	public void setApiDesc(String apiDesc) {
		this.apiDesc = apiDesc;
	}

	public String getApiSubDomain() {
		return apiSubDomain;
	}

	public void setApiSubDomain(String apiSubDomain) {
		this.apiSubDomain = apiSubDomain;
	}

	public String getSandboxUrl() {
		return sandboxUrl;
	}

	public void setSandboxUrl(String sandboxUrl) {
		this.sandboxUrl = sandboxUrl;
	}
	
	 
}

