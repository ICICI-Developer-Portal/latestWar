package com.icici.apigw.model;

import java.sql.Clob;

public class ApiPacket {

	String requestPacket;
	private String requestType;

	public String getRequestPacket() {
		return requestPacket;
	}

	public void setRequestPacket(String string) {
		this.requestPacket = string;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

}