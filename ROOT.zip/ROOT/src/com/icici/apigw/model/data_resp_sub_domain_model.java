package com.icici.apigw.model;

import java.util.ArrayList;

public class data_resp_sub_domain_model {
    public String name;
    public ArrayList<data_resp_sub_api_model> api;
}
