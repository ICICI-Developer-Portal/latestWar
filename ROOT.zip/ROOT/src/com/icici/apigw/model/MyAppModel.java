package com.icici.apigw.model;

import java.util.ArrayList;

public class MyAppModel {
    public MyAppModel() {
        title = "";
        platform = "";
        description = "";
        call_back_url = "";
        scope = "";
        auth_type = "";
    }

    public ArrayList<PlatformModel> platforms;
    public ArrayList<ApiModel> apis;
    public ArrayList<AuthTypeModel> auth_types;

    public String title;
    public String platform;
    public String description;
    public String call_back_url;
    public String scope;
    public String auth_type;
}