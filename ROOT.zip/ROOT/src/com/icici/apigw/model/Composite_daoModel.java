package com.icici.apigw.model;

public class Composite_daoModel {

	String Ben_Bank_Ifsc,Response_Code,Retailer_Code,Datetime,Transaction_Ref,Rem_Name,Status,Rem_Mobile,Ben_Account,Amount,Bank_Rrn,Rem_Acc,Merchantname,Submerchantid,Submerchantname,Payerva,Remark,Uuid;

	public String getBen_Bank_Ifsc() {
		return Ben_Bank_Ifsc;
	}

	public void setBen_Bank_Ifsc(String ben_Bank_Ifsc) {
		Ben_Bank_Ifsc = ben_Bank_Ifsc;
	}

	public String getResponse_Code() {
		return Response_Code;
	}

	public void setResponse_Code(String response_Code) {
		Response_Code = response_Code;
	}

	public String getRetailer_Code() {
		return Retailer_Code;
	}

	public void setRetailer_Code(String retailer_Code) {
		Retailer_Code = retailer_Code;
	}

	public String getDatetime() {
		return Datetime;
	}

	public void setDatetime(String datetime) {
		Datetime = datetime;
	}

	public String getTransaction_Ref() {
		return Transaction_Ref;
	}

	public void setTransaction_Ref(String transaction_Ref) {
		Transaction_Ref = transaction_Ref;
	}

	public String getRem_Name() {
		return Rem_Name;
	}

	public void setRem_Name(String rem_Name) {
		Rem_Name = rem_Name;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

	public String getRem_Mobile() {
		return Rem_Mobile;
	}

	public void setRem_Mobile(String rem_Mobile) {
		Rem_Mobile = rem_Mobile;
	}

	public String getBen_Account() {
		return Ben_Account;
	}

	public void setBen_Account(String ben_Account) {
		Ben_Account = ben_Account;
	}

	public String getAmount() {
		return Amount;
	}

	public void setAmount(String amount) {
		Amount = amount;
	}

	public String getBank_Rrn() {
		return Bank_Rrn;
	}

	public void setBank_Rrn(String bank_Rrn) {
		Bank_Rrn = bank_Rrn;
	}

	public String getRem_Acc() {
		return Rem_Acc;
	}

	public void setRem_Acc(String rem_Acc) {
		Rem_Acc = rem_Acc;
	}

	public String getMerchantname() {
		return Merchantname;
	}

	public void setMerchantname(String merchantname) {
		Merchantname = merchantname;
	}

	public String getSubmerchantid() {
		return Submerchantid;
	}

	public void setSubmerchantid(String submerchantid) {
		Submerchantid = submerchantid;
	}

	public String getSubmerchantname() {
		return Submerchantname;
	}

	public void setSubmerchantname(String submerchantname) {
		Submerchantname = submerchantname;
	}

	public String getPayerva() {
		return Payerva;
	}

	public void setPayerva(String payerva) {
		Payerva = payerva;
	}

	public String getRemark() {
		return Remark;
	}

	public void setRemark(String remark) {
		Remark = remark;
	}

	public String getUuid() {
		return Uuid;
	}

	public void setUuid(String uuid) {
		Uuid = uuid;
	}
	



}
