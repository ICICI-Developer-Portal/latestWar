package com.icici.apigw.model;

public class ApplicationModel {
    public long id;
    public long app_id;
    public String title;
    public String app_key;
    public String status;
    public String platform;
}
