package com.icici.apigw.model;

import java.util.ArrayList;

public class MenuTreeModel {
	private String TAB_NAME;
	private String TYPE;
	private String TREE_ID;
	private String POSITION;
	private String STATUS;
	private String CHILD_COUNT;
	private String API_ID;
	private String LEVEL;
	private ArrayList<MenuTreeModel> children;
    
    
	public String getLEVEL() {
		return LEVEL;
	}
	public void setLEVEL(String lEVEL) {
		LEVEL = lEVEL;
	}
	public String getTAB_NAME() {
		return TAB_NAME;
	}
	public void setTAB_NAME(String tAB_NAME) {
		TAB_NAME = tAB_NAME;
	}
	public String getTYPE() {
		return TYPE;
	}
	public void setTYPE(String tYPE) {
		TYPE = tYPE;
	}
	public String getTREE_ID() {
		return TREE_ID;
	}
	public void setTREE_ID(String tREE_ID) {
		TREE_ID = tREE_ID;
	}
	public String getPOSITION() {
		return POSITION;
	}
	public void setPOSITION(String pOSITION) {
		POSITION = pOSITION;
	}
	public String getSTATUS() {
		return STATUS;
	}
	public void setSTATUS(String sTATUS) {
		STATUS = sTATUS;
	}
	public String getCHILD_COUNT() {
		return CHILD_COUNT;
	}
	public void setCHILD_COUNT(String cHILD_COUNT) {
		CHILD_COUNT = cHILD_COUNT;
	}
	public String getAPI_ID() {
		return API_ID;
	}
	public void setAPI_ID(String aPI_ID) {
		API_ID = aPI_ID;
	}
	public ArrayList<MenuTreeModel> getChildren() {
		return children;
	}
	public void setChildren(ArrayList<MenuTreeModel> children) {
		this.children = children;
	}
    
    
}
