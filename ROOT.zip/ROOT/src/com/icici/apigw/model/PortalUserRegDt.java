package com.icici.apigw.model;

import java.sql.Date;

public class PortalUserRegDt {

	String CITY;
	String RM;
	
	public String getCity() {
		return CITY;
	}

	public void setCity(String CITY) {
		this.CITY = CITY;
	}

	public String getRmName() {
		return RM;
	}

	public void setRmName(String RM) {
		this.RM = RM;
	}

	String userName;
	String firstName;
	String lastName;
	String fullName;
	String email;
	String companyName;
	String contactNo;
	String tncConfirmed;
	Date tncConfirmedDt;
	String domainNm;
	String approverName;
	String approverEmailId;
	Date requestDt;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getTncConfirmed() {
		return tncConfirmed;
	}

	public void setTncConfirmed(String tncConfirmed) {
		this.tncConfirmed = tncConfirmed;
	}

	public Date getTncConfirmedDt() {
		return tncConfirmedDt;
	}

	public void setTncConfirmedDt(Date tncConfirmedDt) {
		this.tncConfirmedDt = tncConfirmedDt;
	}

	public String getDomainNm() {
		return domainNm;
	}

	public void setDomainNm(String domainNm) {
		this.domainNm = domainNm;
	}

	public String getApproverName() {
		return approverName;
	}

	public void setApproverName(String approverName) {
		this.approverName = approverName;
	}

	public String getApproverEmailId() {
		return approverEmailId;
	}

	public void setApproverEmailId(String approverEmailId) {
		this.approverEmailId = approverEmailId;
	}

	public Date getRequestDt() {
		return requestDt;
	}

	public void setRequestDt(Date requestDt) {
		this.requestDt = requestDt;
	}

	@Override
	public String toString() {
		return "PortalUserRegDt [userName=" + userName + "]";
	}
	
}
