package com.icici.apigw.model;

public class ApiModel {
    public ApiModel(){
        selected = false;
    }
    public String name;
    public String key;
    public boolean selected;
}
