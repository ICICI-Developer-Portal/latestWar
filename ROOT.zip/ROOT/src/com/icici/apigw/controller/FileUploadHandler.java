package com.icici.apigw.controller;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;

import com.icici.apigw.dao.ApiDataDao;
import com.icici.apigw.dao.ApiDataDaoImpl;
import com.icici.apigw.util.GwConstants;


/**
 * Servlet implementation class FileUploadHandler
 */
@WebServlet("/fileUpload")
public class FileUploadHandler extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private final String upload_path = GwConstants.CERTIFICATE_UPLOADPATH;
	private static final Logger log = Logger.getLogger(FileUploadHandler.class);  
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FileUploadHandler() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String requestId = request.getParameter("requestId");
		if(requestId != null ) {
			doPost(request, response);
		}
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if(ServletFileUpload.isMultipartContent(request)) {
			try {
				log.info("Inside doPost.try...");
				log.info("upload_path :: "+upload_path);
				List<FileItem> list = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(request);
				log.info("List : "+list.size());
				String FolderName = null;
				for(FileItem item : list) {
					if(item.isFormField()){
						String fieldName = item.getFieldName();
						FolderName = item.getString();
						log.info("Field Value  : "+FolderName);
						log.info("Field Value Length : "+FolderName.length());
					}
					else {
						FolderName = item.getFieldName();
					}
				}
				if(FolderName != null && FolderName.trim().length() > 0) {
					for(FileItem item : list) {
						if(!item.isFormField()) {
							File directory=new File(upload_path+"/"+ FolderName);
							log.info("Directory exist: "+directory.exists());
							if(!directory.exists()) {
								directory.mkdir();
								log.info("Directory "+directory+" Created...");
							}
							log.info("Directory exist: "+directory.exists());
							
							String fileName = new File(item.getName()).getName();
							String filePath = upload_path+"/"+ FolderName +"/"+ fileName;
							item.write(new File(filePath));
							request.setAttribute("message", "file uploaded successfully !!!");
							request.setAttribute("Filepath", filePath);
							String json = "{\n" +
									"	\"status\":\"SUCCESS\",\r\n" + 
					                "    \"FilePath\": \""+filePath+"\"\n" +
					                "    }";
							
					        /**********************************Code to Update details in database ***********************************************/
					        String responseString = null;
							try {
					    		ApiDataDao apiDataDao = new ApiDataDaoImpl();
					    		boolean isSaved = apiDataDao.updateFilePathDetails(filePath,filePath,FolderName);
//					    		if(isSaved) {
//					    			return Response.ok("Ok").build();
//					    		}else {
//					    			return Response.serverError().build();
//					    		}
					    		
					    		if(isSaved) {
									responseString = "{\r\n" + 
											"	\"status\":\"SUCCESS\"\r\n" + 
											"}";
								}
								else
								{
									responseString = "{\r\n" + 
											"	\"status\":\"FAILURE\"\r\n" + 
											"	\"msg\":\"Jira ID not found.\"\r\n" +
											"}";
								}
					        }catch (Exception e){
					            e.printStackTrace();
					        }
							
							log.info("Inside doPost.setAttribut...");
							PrintWriter out = response.getWriter();
					        response.setContentType("application/json");
					        response.setCharacterEncoding("UTF-8");
					        out.print(json);
					        out.flush();
							/*********************************************************************************/
						}
					}
				}
				else {
					log.info("Request ID not provided...");
					request.setAttribute("message", "Request ID not provided...");
				}
				
			}
			catch (Exception e) {
				request.setAttribute("message", "file uploaded failed due to : "+e);
				StringWriter errors = new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				log.error("Exception Occured :: "+errors);
				
				String json = "{\n" +
						"	\"status\":\"FAILURE\",\r\n" + 
		                "    \"message\": \"Exception occures : "+e.getMessage()+"\"\n" +
		                "    }";
				
				log.info("Inside doPost.setAttribut...");
				PrintWriter out = response.getWriter();
//		        response.setContentType("application/json");
		        response.setCharacterEncoding("UTF-8");
		        out.print(json);
		        out.flush();
			}
		}
		log.info("Outside doPost.if...");
//		request.getRequestDispatcher("/result.jsp").forward(request, response);
	}

}
