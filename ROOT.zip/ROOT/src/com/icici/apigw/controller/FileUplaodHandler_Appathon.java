package com.icici.apigw.controller;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.log4j.Logger;

import com.icici.apigw.dao.ApiDataDao;
import com.icici.apigw.dao.ApiDataDaoImpl;
import com.icici.apigw.util.GwConstants;

@WebServlet("/FileUplaodHandler_Appathon")
public class FileUplaodHandler_Appathon extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private final String upload_path_appathon = GwConstants.CERTIFICATE_UPLOADPATH_APPATHON;
	private static final Logger log = Logger.getLogger(FileUploadHandler.class);  
       
    public FileUplaodHandler_Appathon() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String requestId = request.getParameter("requestId");
		if(requestId != null ) {
			doPost(request, response);
		}
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if(ServletFileUpload.isMultipartContent(request)) {
			try {
				log.info("Inside doPost.try...");
				log.info("upload_path :: "+upload_path_appathon);
				List<FileItem> list = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(request);
				log.info("List : "+list.size());
				String FolderName = null;
				for(FileItem item : list) {
					if(item.isFormField()){
						String fieldName = item.getFieldName();
						FolderName = item.getString();
						log.info("Field Value  : "+FolderName);
						log.info("Field Value Length : "+FolderName.length());
					}
					else {
						FolderName = item.getFieldName();
					}
				}
				if(FolderName != null && FolderName.trim().length() > 0) {
					for(FileItem item : list) {
						if(!item.isFormField()) {
							File directory=new File(upload_path_appathon+"/"+ FolderName);
							log.info("Directory exist: "+directory.exists());
							if(!directory.exists()) {
								directory.mkdir();
								log.info("Directory "+directory+" Created...");
							}
							log.info("Directory exist: "+directory.exists());
							
							String fileName = new File(item.getName()).getName();
							String filePath = upload_path_appathon+"/"+ FolderName +"/"+ fileName;
							item.write(new File(filePath));
							request.setAttribute("message", "file uploaded successfully !!!");
							request.setAttribute("Filepath", filePath);
							String json = "{\n" +
									"	\"status\":\"SUCCESS\",\r\n" + 
					                "    \"FilePath\": \""+filePath+"\"\n" +
					                "    }";
							
					        /**********************************Code to Update details in database ***********************************************/
					        String responseString = null;
							try {
					    		ApiDataDao apiDataDao = new ApiDataDaoImpl();
					    		boolean isSaved = apiDataDao.updateFilePathDetailsAppathon(filePath,filePath,FolderName);
					    		if(isSaved) {
									responseString = "{\r\n" + 
											"	\"status\":\"SUCCESS\"\r\n" + 
											"}";
								}
								else
								{
									responseString = "{\r\n" + 
											"	\"status\":\"FAILURE\"\r\n" + 
											"	\"msg\":\"Jira ID not found.\"\r\n" +
											"}";
								}
					        }catch (Exception e){
					            e.printStackTrace();
					        }
							
							log.info("Inside doPost.setAttribut...");
							PrintWriter out = response.getWriter();
					        response.setContentType("application/json");
					        response.setCharacterEncoding("UTF-8");
					       /* response.getWriter().append(json);
					        response.flushBuffer();*/
					        out.print(json);
					        out.flush();
							/*********************************************************************************/
						}
					}
				}
				else {
					log.info("Request ID not provided...");
					request.setAttribute("message", "Request ID not provided...");
				}
				
			}
			catch (Exception e) {
				request.setAttribute("message", "file uploaded failed due to : "+e);
				StringWriter errors = new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				log.error("Exception Occured :: "+errors);
				
				String json = "{\n" +
						"	\"status\":\"FAILURE\",\r\n" + 
		                "    \"message\": \"Exception occures : "+e.getMessage()+"\"\n" +
		                "    }";
				
				log.info("Inside doPost.setAttribut...");
				PrintWriter out = response.getWriter();
                /*response.setContentType("application/json");*/
		        response.setCharacterEncoding("UTF-8");
		        out.print(json);
		        out.flush();
			}
		}
		log.info("Outside doPost.if...");
    /*request.getRequestDispatcher("/result.jsp").forward(request, response);*/
	}

}
