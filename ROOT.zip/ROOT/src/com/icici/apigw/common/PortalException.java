package com.icici.apigw.common;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public class PortalException extends Exception {

	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = LogManager.getLogger(PortalException.class);

	public PortalException(String message) {
		LOGGER.error(message);
	}

	public PortalException(Throwable throwable) {
		LOGGER.error(throwable.getMessage(), throwable);
	}

	public PortalException(String message, Throwable throwable) {
		LOGGER.error(message, throwable);
	}

}
