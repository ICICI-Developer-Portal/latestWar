package com.icici.apigw.dao;

import java.sql.SQLException;
import java.util.List;

import com.icici.apigw.model.LoginModel;

public interface CmsUsersDao {

	LoginModel login(String username, String password) throws SQLException;

	boolean isUsernameExist(String email) throws SQLException;
	
	boolean isEmailExist(String email) throws SQLException;

	long registration(String username, String password, String email, String firstname, String lastname, String ip, String mobileno, int AutoApprove)
			throws SQLException;

	boolean insertOrUpdateOtp(String mobileNo, String otp) throws SQLException;

	String verifyOtp(String mobileNo, String otp) throws SQLException;
	
	boolean isUserEnabled(long id, String password) throws SQLException;
	
	List<String> getRegPendingUsers() throws SQLException;
	
	boolean enableUser(String username) throws SQLException;
	
	boolean rejectUser(String username) throws SQLException;
	boolean isUsernamePasswordExist(String username, String password);

}
